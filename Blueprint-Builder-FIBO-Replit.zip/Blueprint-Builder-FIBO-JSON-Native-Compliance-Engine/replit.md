# FIBO Compliance Engine

A React-based compliance validation tool for financial assets using FIBO (Financial Industry Business Ontology) standards.

## Overview
This application allows users to validate financial asset definitions against FIBO standards using Google's Gemini AI for intelligent compliance analysis.

## Tech Stack
- React 18 with TypeScript
- Vite for build tooling
- Framer Motion for animations
- Lucide React for icons
- Tailwind CSS for styling
- Google Gemini API for AI-powered compliance checking

## Project Structure
```
├── App.tsx                    # Main application component
├── index.tsx                  # React entry point
├── index.html                 # HTML template
├── types.ts                   # TypeScript type definitions
├── components/
│   ├── JsonEditor.tsx         # JSON input editor component
│   ├── StatusBadge.tsx        # Status indicator component
│   └── ViolationsList.tsx     # Compliance violations display
├── services/
│   └── complianceEngine.ts    # Gemini AI compliance service
└── vite.config.ts             # Vite configuration
```

## Environment Variables
- `GEMINI_API_KEY` - Required for AI-powered compliance checking

## Running the App
```bash
npm install
npm run dev
```

The app runs on port 5000.

## Features
- JSON asset definition editor
- FIBO compliance validation
- Semantic and schema validation
- Audit ledger for tracking validation history
- Sample templates for testing
