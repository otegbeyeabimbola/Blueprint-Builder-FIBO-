import express from 'express';
import { GoogleGenerativeAI } from '@google/generative-ai';
import crypto from 'crypto';

const app = express();
app.use(express.json());

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

const FIBO_SCHEMA = {
  required: ['asset_id', 'asset_type', 'issuer_name', 'is_fiat_denominated', 'price', 'required_documentation'],
  properties: {
    asset_id: { type: 'string', minLength: 5 },
    asset_type: { enum: ['Stock', 'Bond', 'Derivative', 'FX'] },
    issuer_name: { type: 'string', minLength: 1 },
    is_fiat_denominated: { type: 'boolean' },
    currency: { enum: ['USD', 'EUR', 'GBP'], nullable: true },
    price: { type: 'number', minimum: 0 },
    maturity_date: { type: 'string', pattern: '^\\d{4}-\\d{2}-\\d{2}$', nullable: true },
    required_documentation: { type: 'array', items: { type: 'string' } }
  }
};

function validateSchema(asset) {
  const violations = [];
  
  for (const field of FIBO_SCHEMA.required) {
    if (asset[field] === undefined || asset[field] === null) {
      violations.push({
        category: 'SCHEMA_VIOLATION',
        type: 'MissingRequiredField',
        field,
        description: `Required field "${field}" is missing`,
        fix_suggestion: `Add the "${field}" field to your asset definition`
      });
    }
  }
  
  if (asset.asset_id && (typeof asset.asset_id !== 'string' || asset.asset_id.length < 5)) {
    violations.push({
      category: 'SCHEMA_VIOLATION',
      type: 'InvalidFormat',
      field: 'asset_id',
      description: 'asset_id must be a string with at least 5 characters',
      fix_suggestion: 'Ensure asset_id is at least 5 characters long'
    });
  }
  
  if (asset.asset_type && !['Stock', 'Bond', 'Derivative', 'FX'].includes(asset.asset_type)) {
    violations.push({
      category: 'SCHEMA_VIOLATION',
      type: 'InvalidEnum',
      field: 'asset_type',
      description: `Invalid asset_type "${asset.asset_type}". Must be one of: Stock, Bond, Derivative, FX`,
      fix_suggestion: 'Use one of the valid asset types: Stock, Bond, Derivative, FX'
    });
  }
  
  if (asset.price !== undefined && (typeof asset.price !== 'number' || asset.price < 0)) {
    violations.push({
      category: 'SCHEMA_VIOLATION',
      type: 'InvalidValue',
      field: 'price',
      description: 'Price must be a non-negative number',
      fix_suggestion: 'Ensure price is a positive number'
    });
  }
  
  if (asset.currency && !['USD', 'EUR', 'GBP'].includes(asset.currency)) {
    violations.push({
      category: 'SCHEMA_VIOLATION',
      type: 'InvalidEnum',
      field: 'currency',
      description: `Invalid currency "${asset.currency}". Must be one of: USD, EUR, GBP`,
      fix_suggestion: 'Use one of the valid currencies: USD, EUR, GBP'
    });
  }
  
  return violations;
}

async function validateSemantic(asset) {
  const violations = [];
  
  try {
    const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
    
    const prompt = `You are a FIBO (Financial Industry Business Ontology) compliance expert. Analyze this financial asset for semantic compliance issues.

Asset JSON:
${JSON.stringify(asset, null, 2)}

FIBO Semantic Rules to check:
1. Bonds MUST have "Prospectus" in required_documentation
2. If is_fiat_denominated is true, currency field should be present
3. Stocks should have "Prospectus" and "Term Sheet" in documentation
4. Asset IDs should follow naming conventions (type prefix recommended)
5. Issuer names should be proper legal entity names

Respond ONLY with a JSON array of violations found. Each violation must have:
- category: "SEMANTIC_VIOLATION"
- type: short error type name
- field: the field with the issue
- description: clear explanation
- fix_suggestion: how to fix it

If no violations, return an empty array [].
Return ONLY valid JSON, no markdown.`;

    const result = await model.generateContent(prompt);
    const responseText = result.response.text().trim();
    
    const jsonMatch = responseText.match(/\[[\s\S]*\]/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      if (Array.isArray(parsed)) {
        violations.push(...parsed);
      }
    }
  } catch (error) {
    console.error('Gemini semantic check error:', error.message);
  }
  
  return violations;
}

function hashString(str) {
  return crypto.createHash('sha256').update(str).digest('hex');
}

app.post('/api/validate', async (req, res) => {
  try {
    const { payload } = req.body;
    
    if (!payload) {
      return res.status(400).json({ detail: 'Missing payload' });
    }
    
    let asset;
    try {
      asset = typeof payload === 'string' ? JSON.parse(payload) : payload;
    } catch (e) {
      return res.json({
        blueprint_version: '1.0.0',
        status: 'FAILED_SCHEMA',
        exit_code: 2,
        trace_id: hashString(payload || ''),
        canonical_json: '',
        violations_history: [{
          category: 'CRITICAL_PARSING_ERROR',
          type: 'InvalidJSON',
          field: 'payload',
          description: 'Failed to parse JSON payload',
          fix_suggestion: 'Ensure the input is valid JSON'
        }],
        last_violations: [],
        iterations: 1,
        was_corrected_by_patcher: false,
        asset: null,
        timestamp: new Date().toISOString()
      });
    }
    
    const schemaViolations = validateSchema(asset);
    const semanticViolations = await validateSemantic(asset);
    
    const allViolations = [...schemaViolations, ...semanticViolations];
    const canonicalJson = JSON.stringify(asset, Object.keys(asset).sort(), 2);
    const traceId = hashString(canonicalJson);
    
    let status = 'SUCCESS';
    let exitCode = 0;
    
    if (schemaViolations.length > 0) {
      status = 'FAILED_SCHEMA';
      exitCode = 2;
    } else if (semanticViolations.length > 0) {
      status = 'FAILED_SEMANTIC';
      exitCode = 1;
    }
    
    const envelope = {
      blueprint_version: '1.0.0',
      status,
      exit_code: exitCode,
      trace_id: traceId,
      canonical_json: canonicalJson,
      violations_history: allViolations,
      last_violations: allViolations,
      iterations: 1,
      was_corrected_by_patcher: false,
      asset,
      timestamp: new Date().toISOString()
    };
    
    res.json(envelope);
    
  } catch (error) {
    console.error('Validation error:', error);
    res.status(500).json({ detail: error.message });
  }
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`FIBO Compliance API running on port ${PORT}`);
});
