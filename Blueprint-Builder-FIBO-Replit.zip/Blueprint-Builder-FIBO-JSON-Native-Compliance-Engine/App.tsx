import React, { useState, useEffect, useRef } from 'react';
import { JsonEditor } from './components/JsonEditor';
import { StatusBadge } from './components/StatusBadge';
import { ViolationsList } from './components/ViolationsList';
import { runAgenticComplianceLoop, hashString, replayComplianceCheck } from './services/complianceEngine';
import { ComplianceEnvelope, LedgerEntry } from './types';
import { Play, RotateCcw, ShieldCheck, History, Database, Code, FileJson, ArrowRight, Zap, Check, LayoutGrid, AlertCircle, X, ChevronDown, Search, RefreshCw, Filter, Calendar, ArrowUp, ArrowDown } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Pre-defined demo data
const DEMO_VALID = {
  "asset_id": "TSLA2025",
  "asset_type": "Stock",
  "issuer_name": "Tesla Inc",
  "is_fiat_denominated": true,
  "currency": "USD",
  "price": 250.50,
  "required_documentation": ["Prospectus", "Term Sheet"]
};

const DEMO_SEMANTIC_FAIL = {
  "asset_id": "BOND2030",
  "asset_type": "Bond",
  "issuer_name": "Global Corp",
  "is_fiat_denominated": true,
  "currency": "USD",
  "price": 1000.00,
  "required_documentation": ["Term Sheet"]
};

const DEMO_SCHEMA_FAIL = {
  "asset_id": "bad", 
  "asset_type": "Crypto", 
  "price": -50 
};

// UUID Polyfill for non-secure contexts
const generateId = () => {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

export default function App() {
  const [inputJson, setInputJson] = useState<string>(JSON.stringify(DEMO_SEMANTIC_FAIL, null, 2));
  const [envelope, setEnvelope] = useState<ComplianceEnvelope | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [ledger, setLedger] = useState<LedgerEntry[]>([]);
  const [activeTab, setActiveTab] = useState<'current' | 'ledger'>('current');
  const [notification, setNotification] = useState<{ message: string, type: 'error' | 'success' } | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const mobileMenuRef = useRef<HTMLDivElement>(null);
  
  // Ledger Search & Filters
  const [ledgerSearchQuery, setLedgerSearchQuery] = useState('');
  const [replayingId, setReplayingId] = useState<string | null>(null);
  const [replayStatus, setReplayStatus] = useState<Record<string, 'success' | 'error'>>({});
  const [showFilters, setShowFilters] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [filterType, setFilterType] = useState<string>('ALL');
  const [filterStartDate, setFilterStartDate] = useState<string>('');
  const [filterEndDate, setFilterEndDate] = useState<string>('');
  
  // Sorting State
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' }>({ key: 'timestamp', direction: 'desc' });

  // History Management
  const historyRef = useRef<string[]>([JSON.stringify(DEMO_SEMANTIC_FAIL, null, 2)]);
  const historyIndexRef = useRef<number>(0);
  const historyTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);

  // Load ledger from local storage on mount
  useEffect(() => {
    try {
      const savedLedger = localStorage.getItem('compliance_ledger');
      if (savedLedger) {
        try {
          const parsed = JSON.parse(savedLedger);
          if (Array.isArray(parsed)) {
            setLedger(parsed);
          } else {
            throw new Error("Invalid ledger format");
          }
        } catch (parseError) {
          console.error("Ledger parse error:", parseError);
          setNotification({ 
            message: "Detected corrupted ledger data. History has been reset.", 
            type: 'error' 
          });
          localStorage.removeItem('compliance_ledger');
        }
      }
    } catch (storageError) {
      console.error("Storage access error:", storageError);
      setNotification({ 
        message: "Unable to access local storage. Ledger history will not be saved.", 
        type: 'error' 
      });
    }
  }, []);

  // Clear notification after delay
  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => setNotification(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  // Handle click outside to close mobile menu
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (mobileMenuRef.current && !mobileMenuRef.current.contains(event.target as Node)) {
        setIsMobileMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const updateHistoryState = () => {
    setCanUndo(historyIndexRef.current > 0);
    setCanRedo(historyIndexRef.current < historyRef.current.length - 1);
  };

  const handleJsonChange = (newValue: string) => {
    setInputJson(newValue);

    if (historyTimeoutRef.current) clearTimeout(historyTimeoutRef.current);

    historyTimeoutRef.current = setTimeout(() => {
      const currentIndex = historyIndexRef.current;
      const currentHistory = historyRef.current;

      // Only push if different from current history head
      if (newValue !== currentHistory[currentIndex]) {
        // Slice history to current point (remove future redo states)
        const newHistory = currentHistory.slice(0, currentIndex + 1);
        newHistory.push(newValue);
        
        // Limit history size if needed (optional)
        if (newHistory.length > 50) newHistory.shift();

        historyRef.current = newHistory;
        historyIndexRef.current = newHistory.length - 1;
        updateHistoryState();
      }
    }, 600); // 600ms debounce
  };

  const handleUndo = () => {
    if (historyIndexRef.current > 0) {
      historyIndexRef.current -= 1;
      const prevValue = historyRef.current[historyIndexRef.current];
      setInputJson(prevValue);
      updateHistoryState();
      // Clear any pending history updates to prevent overwriting the undo
      if (historyTimeoutRef.current) clearTimeout(historyTimeoutRef.current);
    }
  };

  const handleRedo = () => {
    if (historyIndexRef.current < historyRef.current.length - 1) {
      historyIndexRef.current += 1;
      const nextValue = historyRef.current[historyIndexRef.current];
      setInputJson(nextValue);
      updateHistoryState();
      if (historyTimeoutRef.current) clearTimeout(historyTimeoutRef.current);
    }
  };

  const loadDemo = (data: any) => {
    const jsonStr = JSON.stringify(data, null, 2);
    setInputJson(jsonStr);
    
    // Add load demo to history as a distinct step
    const currentIndex = historyIndexRef.current;
    const newHistory = historyRef.current.slice(0, currentIndex + 1);
    newHistory.push(jsonStr);
    historyRef.current = newHistory;
    historyIndexRef.current = newHistory.length - 1;
    updateHistoryState();
    
    setEnvelope(null);
    setActiveTab('current');
  };

  const saveLedger = (newLedger: LedgerEntry[]) => {
    try {
      localStorage.setItem('compliance_ledger', JSON.stringify(newLedger));
    } catch (e) {
      console.error("Save failed:", e);
      setNotification({ 
        message: "Failed to save ledger to storage (Quota Exceeded or Access Denied).", 
        type: 'error' 
      });
    }
  };

  const handleRunCompliance = async () => {
    setIsRunning(true);
    setEnvelope(null);

    // Simulate network/processing delay for effect
    await new Promise(resolve => setTimeout(resolve, 800));

    try {
      const result = await runAgenticComplianceLoop(inputJson);
      const inputHash = await hashString(inputJson);

      setEnvelope(result);
      
      const newEntry: LedgerEntry = {
        id: generateId(),
        timestamp: new Date().toISOString(),
        input_hash: inputHash,
        envelope: result
      };

      const updatedLedger = [newEntry, ...ledger];
      setLedger(updatedLedger);
      saveLedger(updatedLedger);
      
    } catch (err) {
      setNotification({
        message: "An unexpected error occurred during compliance check.",
        type: 'error'
      });
    } finally {
      setIsRunning(false);
      setActiveTab('current');
    }
  };

  const handleReplay = async (e: React.MouseEvent, entry: LedgerEntry) => {
    e.stopPropagation();
    setReplayingId(entry.id);
    
    // Simulate slight network delay to mimic backend roundtrip
    await new Promise(resolve => setTimeout(resolve, 700));

    try {
      const result = await replayComplianceCheck(entry.envelope);
      const status = result.valid && result.integrity ? 'success' : 'error';
      
      setReplayStatus(prev => ({ ...prev, [entry.id]: status }));
      
      setNotification({
        message: result.message,
        type: status
      });

      // Only auto-clear success status. Keep errors persistent to warn user of corruption.
      if (status === 'success') {
        setTimeout(() => {
          setReplayStatus(prev => {
            const next = { ...prev };
            delete next[entry.id];
            return next;
          });
        }, 4000);
      }

    } catch (err) {
      setNotification({
        message: "Replay failed due to an internal error.",
        type: 'error'
      });
    } finally {
      setReplayingId(null);
    }
  };

  const handleSort = (key: string) => {
    setSortConfig(current => ({
        key,
        direction: current.key === key && current.direction === 'desc' ? 'asc' : 'desc'
    }));
  };

  // Filter and Sort ledger based on search query, active filters, and sort config
  const filteredAndSortedLedger = ledger.filter(entry => {
    const q = ledgerSearchQuery.toLowerCase();
    
    // Text Search
    const matchesSearch = !ledgerSearchQuery || 
        entry.envelope.trace_id.toLowerCase().includes(q) ||
        entry.envelope.status.toLowerCase().includes(q) ||
        (entry.envelope.asset?.asset_type || '').toLowerCase().includes(q);

    // Status Filter
    const matchesStatus = filterStatus === 'ALL' || entry.envelope.status === filterStatus;

    // Type Filter
    const matchesType = filterType === 'ALL' || (entry.envelope.asset?.asset_type || 'Unknown') === filterType;

    // Date Range Filter
    let matchesDate = true;
    const entryDate = new Date(entry.timestamp).getTime();
    
    if (filterStartDate) {
        const start = new Date(filterStartDate).setHours(0,0,0,0);
        if (entryDate < start) matchesDate = false;
    }
    if (filterEndDate) {
        const end = new Date(filterEndDate).setHours(23,59,59,999);
        if (entryDate > end) matchesDate = false;
    }

    return matchesSearch && matchesStatus && matchesType && matchesDate;
  }).sort((a, b) => {
    switch (sortConfig.key) {
        case 'timestamp':
            return sortConfig.direction === 'asc' 
                ? new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
                : new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
        case 'status':
            return sortConfig.direction === 'asc'
                ? a.envelope.status.localeCompare(b.envelope.status)
                : b.envelope.status.localeCompare(a.envelope.status);
        case 'trace_id':
            return sortConfig.direction === 'asc'
                ? a.envelope.trace_id.localeCompare(b.envelope.trace_id)
                : b.envelope.trace_id.localeCompare(a.envelope.trace_id);
        case 'iterations':
            return sortConfig.direction === 'asc'
                ? a.envelope.iterations - b.envelope.iterations
                : b.envelope.iterations - a.envelope.iterations;
        case 'type':
            const typeA = a.envelope.asset?.asset_type || '';
            const typeB = b.envelope.asset?.asset_type || '';
            return sortConfig.direction === 'asc'
                ? typeA.localeCompare(typeB)
                : typeB.localeCompare(typeA);
        default:
            return 0;
    }
  });

  const renderSortArrow = (key: string) => {
      if (sortConfig.key !== key) return null;
      return sortConfig.direction === 'asc' 
        ? <ArrowUp className="w-3 h-3 text-indigo-400" /> 
        : <ArrowDown className="w-3 h-3 text-indigo-400" />;
  };

  const getRowClassName = (entryId: string, status: 'success' | 'error' | undefined) => {
    const base = "group transition-colors cursor-pointer border-l-2";
    if (status === 'error') return `${base} bg-rose-500/5 border-rose-500`;
    if (status === 'success') return `${base} bg-emerald-500/5 border-emerald-500`;
    return `${base} border-transparent hover:bg-white/[0.02]`;
  };

  return (
    <div className="min-h-screen relative font-sans selection:bg-indigo-500/30 text-slate-200">
      
      {/* Background Elements */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute inset-0 bg-slate-950" />
        <div className="absolute inset-0 bg-grid-pattern opacity-40" />
        <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-indigo-500/10 rounded-full blur-[100px]" />
        <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-emerald-500/5 rounded-full blur-[100px]" />
      </div>

      {/* Notification Toast */}
      <AnimatePresence>
        {notification && (
          <motion.div
            initial={{ opacity: 0, y: -20, x: '-50%' }}
            animate={{ opacity: 1, y: 0, x: '-50%' }}
            exit={{ opacity: 0, y: -20, x: '-50%' }}
            className="fixed top-24 left-1/2 z-[60] flex items-center gap-3 px-4 py-3 rounded-xl bg-slate-900/90 backdrop-blur-md border border-white/10 shadow-2xl"
          >
            {notification.type === 'error' ? (
              <AlertCircle className="w-5 h-5 text-rose-400" />
            ) : (
              <Check className="w-5 h-5 text-emerald-400" />
            )}
            <span className="text-sm font-medium text-slate-200">{notification.message}</span>
            <button 
              onClick={() => setNotification(null)}
              className="ml-2 p-1 hover:bg-white/10 rounded-full transition-colors"
            >
              <X className="w-4 h-4 text-slate-400" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-white/5 bg-slate-950/70 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 md:px-6 h-18 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="p-2.5 bg-gradient-to-br from-indigo-600 to-indigo-700 rounded-xl shadow-lg shadow-indigo-500/20 ring-1 ring-white/10">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white tracking-tight">Blueprint Builder</h1>
              <p className="text-[11px] text-slate-400 font-medium uppercase tracking-wider">Compliance Engine <span className="text-slate-600 mx-1">|</span> v1.0</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4 md:gap-6">
             {/* Desktop Menu */}
             <div className="hidden md:flex bg-slate-900/50 p-1 rounded-lg border border-white/5 ring-1 ring-white/5 backdrop-blur-sm">
                {[
                  { label: "Valid Asset", data: DEMO_VALID, color: "hover:text-emerald-400" },
                  { label: "Semantic Fail", data: DEMO_SEMANTIC_FAIL, color: "hover:text-amber-400" },
                  { label: "Schema Fail", data: DEMO_SCHEMA_FAIL, color: "hover:text-rose-400" }
                ].map((demo, idx) => (
                  <button 
                    key={idx}
                    onClick={() => loadDemo(demo.data)}
                    className={`px-3 py-1.5 text-xs font-medium text-slate-400 ${demo.color} hover:bg-white/5 rounded-md transition-all duration-200`}
                  >
                    {demo.label}
                  </button>
                ))}
            </div>

            {/* Mobile Dropdown Menu */}
            <div className="relative md:hidden" ref={mobileMenuRef}>
              <button 
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-400 bg-slate-900/50 border border-white/5 rounded-lg hover:bg-white/5 transition-colors ring-1 ring-white/5"
              >
                <span>Presets</span>
                <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${isMobileMenuOpen ? 'rotate-180' : ''}`} />
              </button>
              
              <AnimatePresence>
                {isMobileMenuOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 8, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 8, scale: 0.95 }}
                    className="absolute right-0 top-full mt-2 w-40 bg-slate-900/95 backdrop-blur-xl border border-white/10 rounded-xl shadow-2xl overflow-hidden z-[100] flex flex-col p-1 ring-1 ring-black/50"
                  >
                     {[
                        { label: "Valid Asset", data: DEMO_VALID, color: "text-emerald-400" },
                        { label: "Semantic Fail", data: DEMO_SEMANTIC_FAIL, color: "text-amber-400" },
                        { label: "Schema Fail", data: DEMO_SCHEMA_FAIL, color: "text-rose-400" }
                      ].map((demo, idx) => (
                        <button 
                          key={idx}
                          onClick={() => {
                            loadDemo(demo.data);
                            setIsMobileMenuOpen(false);
                          }}
                          className={`text-left px-3 py-2.5 text-xs font-medium ${demo.color} hover:bg-white/5 rounded-lg transition-colors flex items-center justify-between group`}
                        >
                          {demo.label}
                          <ArrowRight className="w-3 h-3 opacity-0 group-hover:opacity-50 -translate-x-2 group-hover:translate-x-0 transition-all" />
                        </button>
                      ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <a href="#" className="text-slate-500 hover:text-white transition-colors">
              <FileJson className="w-5 h-5" />
            </a>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 md:gap-8">
        
        {/* Left Column: Input */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          <div className="flex items-center justify-between px-1">
             <h2 className="text-sm font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-2">
               <Code className="w-4 h-4 text-indigo-400" />
               Asset Definition
             </h2>
             <span className="text-xs text-slate-500 font-mono">JSON</span>
          </div>
          
          <div className="flex-1 min-h-[500px] flex flex-col gap-4">
            <motion.div 
              layoutId="editor"
              className="flex-1 rounded-2xl overflow-hidden ring-1 ring-white/10 shadow-2xl shadow-black/50"
            >
              <JsonEditor 
                value={inputJson} 
                onChange={handleJsonChange} 
                label="Input Payload"
                onUndo={handleUndo}
                onRedo={handleRedo}
                canUndo={canUndo}
                canRedo={canRedo}
              />
            </motion.div>

            <motion.button
              whileHover={{ scale: isRunning ? 1 : 1.02, y: -2 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleRunCompliance}
              disabled={isRunning}
              className={`
                group relative w-full py-4 rounded-xl font-bold text-sm uppercase tracking-wider shadow-lg transition-all overflow-hidden
                ${isRunning 
                  ? 'bg-slate-800/50 text-slate-500 cursor-not-allowed border border-white/5' 
                  : 'bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white shadow-indigo-500/25 border border-indigo-400/20'
                }
              `}
            >
              <div className="relative z-10 flex items-center justify-center gap-3">
                {isRunning ? (
                  <>
                    <RotateCcw className="w-5 h-5 animate-spin text-indigo-400" />
                    <span>Processing compliance rules...</span>
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5 fill-current" />
                    <span>Run Compliance Check</span>
                  </>
                )}
              </div>
              {/* Button Shine Effect */}
              {!isRunning && (
                <div className="absolute inset-0 -translate-x-full group-hover:animate-[shimmer_1.5s_infinite] bg-gradient-to-r from-transparent via-white/10 to-transparent z-0" />
              )}
            </motion.button>
          </div>
        </div>

        {/* Right Column: Output & Ledger */}
        <div className="lg:col-span-7 flex flex-col gap-4">
           {/* Tabs */}
           <div className="flex gap-1 p-1 bg-slate-900/50 backdrop-blur-md border border-white/5 rounded-xl w-fit">
            {[
              { id: 'current', label: 'Current Execution', icon: Zap },
              { id: 'ledger', label: 'Audit Ledger', icon: Database, count: ledger.length }
            ].map((tab) => (
              <button 
                key={tab.id}
                onClick={() => setActiveTab(tab.id as 'current' | 'ledger')}
                className={`
                  relative px-4 py-2 text-xs font-semibold rounded-lg flex items-center gap-2 transition-all duration-300
                  ${activeTab === tab.id 
                    ? 'text-white bg-white/10 shadow-sm' 
                    : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'
                  }
                `}
              >
                <tab.icon className={`w-3.5 h-3.5 ${activeTab === tab.id ? 'text-indigo-400' : ''}`} />
                {tab.label}
                {tab.count !== undefined && tab.count > 0 && (
                   <span className="ml-1.5 bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded-full text-[10px] min-w-[18px] text-center border border-white/5">{tab.count}</span>
                )}
              </button>
            ))}
           </div>

           <div className="flex-1 bg-slate-900/40 backdrop-blur-sm rounded-2xl border border-white/5 ring-1 ring-white/5 shadow-2xl relative overflow-hidden min-h-[500px]">
             
             <AnimatePresence mode='wait'>
             {activeTab === 'current' ? (
                envelope ? (
                  <motion.div 
                    key="results"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.3 }}
                    className="h-full flex flex-col absolute inset-0"
                  >
                    {/* Status Header */}
                    <div className="bg-slate-900/80 backdrop-blur border-b border-white/5 p-5 flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <StatusBadge status={envelope.status} />
                        {envelope.was_corrected_by_patcher && (
                          <motion.div 
                            initial={{ scale: 0.8, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            className="flex items-center gap-1.5 px-3 py-1 bg-purple-500/10 text-purple-300 border border-purple-500/20 rounded-full"
                          >
                            <Zap className="w-3 h-3 text-purple-400 fill-current" />
                            <span className="text-xs font-semibold tracking-wide">Auto-Corrected</span>
                          </motion.div>
                        )}
                      </div>
                      <div className="text-right">
                        <div className="text-[10px] text-slate-500 font-mono uppercase tracking-wider mb-0.5">Trace ID</div>
                        <div className="text-xs text-indigo-300 font-mono truncate max-w-[120px] bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">{envelope.trace_id}</div>
                      </div>
                    </div>

                    <div className="flex-1 overflow-y-auto p-5 space-y-8 custom-scrollbar">
                      
                      {/* Metric Grid */}
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                         <MetricCard label="Blueprint" value={envelope.blueprint_version} />
                         <MetricCard label="Exit Code" value={envelope.exit_code} fontMono />
                         <MetricCard label="Iterations" value={envelope.iterations} fontMono />
                         <MetricCard label="Corrections" value={envelope.violations_history.length} fontMono highlight={envelope.violations_history.length > 0} />
                      </div>

                      {/* Violations Section */}
                      {envelope.violations_history.length > 0 && (
                        <div className="space-y-3">
                           <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-2 pl-1">
                            <History className="w-3.5 h-3.5" />
                            Correction Log
                           </h3>
                           <ViolationsList violations={envelope.violations_history} />
                        </div>
                      )}

                      {/* Final JSON Output */}
                      <div className="space-y-3 pb-4">
                        <div className="flex items-center justify-between pl-1">
                          <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-2">
                            <LayoutGrid className="w-3.5 h-3.5" />
                            Canonical Output
                          </h3>
                          {envelope.status === 'SUCCESS' && (
                            <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                              <Check className="w-3 h-3" /> Ready for Ledger
                            </span>
                          )}
                        </div>
                        <div className="h-80 rounded-xl overflow-hidden border border-white/5 shadow-inner bg-[#0d1117]">
                          <JsonEditor 
                            value={envelope.canonical_json || JSON.stringify(envelope, null, 2)} 
                            onChange={() => {}} 
                            readOnly 
                          />
                        </div>
                      </div>

                    </div>
                  </motion.div>
                ) : (
                  <motion.div 
                    key="empty"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="h-full flex flex-col items-center justify-center text-slate-600 space-y-6 p-8"
                  >
                    {isRunning ? (
                       <div className="relative">
                         <div className="w-20 h-20 border-4 border-slate-800 rounded-full"></div>
                         <div className="absolute top-0 left-0 w-20 h-20 border-t-4 border-indigo-500 rounded-full animate-spin"></div>
                       </div>
                    ) : (
                      <div className="flex flex-col items-center gap-4">
                        <div className="p-6 bg-slate-900/50 rounded-full ring-1 ring-white/5">
                          <ShieldCheck className="w-12 h-12 text-slate-700" />
                        </div>
                        <p className="text-sm font-medium text-slate-500">Ready to validate asset compliance.</p>
                      </div>
                    )}
                  </motion.div>
                )
             ) : (
               // Ledger Tab
               <motion.div 
                key="ledger"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="h-full flex flex-col absolute inset-0"
               >
                  {/* Ledger Search & Filter Bar */}
                  <div className="p-4 border-b border-white/5 bg-slate-900/40 space-y-3">
                    <div className="flex gap-2">
                        <div className="relative flex-1">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                            <input 
                                type="text"
                                placeholder="Search Trace ID..."
                                value={ledgerSearchQuery}
                                onChange={(e) => setLedgerSearchQuery(e.target.value)}
                                className="w-full bg-slate-950/50 border border-white/10 rounded-lg py-2 pl-10 pr-4 text-xs text-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 placeholder:text-slate-600"
                            />
                        </div>
                        <button 
                            onClick={() => setShowFilters(!showFilters)}
                            className={`p-2 rounded-lg border transition-all duration-200 flex items-center gap-2 text-xs font-medium ${showFilters ? 'bg-indigo-500/20 border-indigo-500/50 text-indigo-300' : 'bg-slate-950/50 border-white/10 text-slate-400 hover:text-slate-200'}`}
                        >
                            <Filter className="w-3.5 h-3.5" />
                            <span className="hidden sm:inline">Filters</span>
                        </button>
                    </div>

                    <AnimatePresence>
                        {showFilters && (
                            <motion.div 
                                initial={{ height: 0, opacity: 0 }}
                                animate={{ height: 'auto', opacity: 1 }}
                                exit={{ height: 0, opacity: 0 }}
                                className="overflow-hidden"
                            >
                                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-1">
                                    {/* Status Filter */}
                                    <div className="space-y-1">
                                        <label className="text-[10px] text-slate-500 font-medium uppercase tracking-wider ml-1">Status</label>
                                        <div className="relative">
                                            <select 
                                                value={filterStatus}
                                                onChange={(e) => setFilterStatus(e.target.value)}
                                                className="w-full bg-slate-950/50 border border-white/10 rounded-lg py-1.5 pl-3 pr-8 text-xs text-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 appearance-none"
                                            >
                                                <option value="ALL">All Statuses</option>
                                                <option value="SUCCESS">Success</option>
                                                <option value="FAILED_SCHEMA">Schema Failed</option>
                                                <option value="FAILED_SEMANTIC">Semantic Failed</option>
                                            </select>
                                            <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-500 pointer-events-none" />
                                        </div>
                                    </div>

                                    {/* Asset Type Filter */}
                                    <div className="space-y-1">
                                        <label className="text-[10px] text-slate-500 font-medium uppercase tracking-wider ml-1">Asset Type</label>
                                        <div className="relative">
                                            <select 
                                                value={filterType}
                                                onChange={(e) => setFilterType(e.target.value)}
                                                className="w-full bg-slate-950/50 border border-white/10 rounded-lg py-1.5 pl-3 pr-8 text-xs text-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 appearance-none"
                                            >
                                                <option value="ALL">All Types</option>
                                                <option value="Stock">Stock</option>
                                                <option value="Bond">Bond</option>
                                                <option value="Derivative">Derivative</option>
                                                <option value="FX">FX</option>
                                            </select>
                                            <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-500 pointer-events-none" />
                                        </div>
                                    </div>

                                    {/* Date Range Start */}
                                    <div className="space-y-1">
                                        <label className="text-[10px] text-slate-500 font-medium uppercase tracking-wider ml-1">From Date</label>
                                        <div className="relative">
                                            <input 
                                                type="date" 
                                                value={filterStartDate}
                                                onChange={(e) => setFilterStartDate(e.target.value)}
                                                className="w-full bg-slate-950/50 border border-white/10 rounded-lg py-1.5 px-3 text-xs text-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 [color-scheme:dark]"
                                            />
                                        </div>
                                    </div>

                                    {/* Date Range End */}
                                    <div className="space-y-1">
                                        <label className="text-[10px] text-slate-500 font-medium uppercase tracking-wider ml-1">To Date</label>
                                        <div className="relative">
                                            <input 
                                                type="date" 
                                                value={filterEndDate}
                                                onChange={(e) => setFilterEndDate(e.target.value)}
                                                className="w-full bg-slate-950/50 border border-white/10 rounded-lg py-1.5 px-3 text-xs text-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 [color-scheme:dark]"
                                            />
                                        </div>
                                    </div>
                                </div>
                            </motion.div>
                        )}
                    </AnimatePresence>
                  </div>

                  <div className="overflow-x-auto custom-scrollbar flex-1">
                    <table className="w-full text-left text-xs text-slate-400">
                      <thead className="text-xs uppercase bg-slate-900 text-slate-300 font-semibold sticky top-0 z-20 shadow-md border-b border-white/5">
                        <tr>
                          <th 
                            className="px-5 py-4 tracking-wider cursor-pointer hover:text-white transition-colors select-none min-w-[140px]"
                            onClick={() => handleSort('status')}
                          >
                            <div className="flex items-center gap-2">
                              Status
                              {renderSortArrow('status')}
                            </div>
                          </th>
                          <th 
                            className="px-5 py-4 tracking-wider cursor-pointer hover:text-white transition-colors select-none whitespace-nowrap"
                            onClick={() => handleSort('timestamp')}
                          >
                             <div className="flex items-center gap-2">
                               Timestamp
                               {renderSortArrow('timestamp')}
                             </div>
                          </th>
                          <th 
                            className="px-5 py-4 tracking-wider cursor-pointer hover:text-white transition-colors select-none"
                            onClick={() => handleSort('trace_id')}
                          >
                             <div className="flex items-center gap-2">
                               Trace ID
                               {renderSortArrow('trace_id')}
                             </div>
                          </th>
                          <th 
                            className="px-5 py-4 text-center tracking-wider cursor-pointer hover:text-white transition-colors select-none"
                            onClick={() => handleSort('iterations')}
                          >
                             <div className="flex items-center justify-center gap-2">
                               Iters
                               {renderSortArrow('iterations')}
                             </div>
                          </th>
                          <th 
                            className="px-5 py-4 tracking-wider cursor-pointer hover:text-white transition-colors select-none"
                            onClick={() => handleSort('type')}
                          >
                             <div className="flex items-center gap-2">
                               Type
                               {renderSortArrow('type')}
                             </div>
                          </th>
                          <th className="px-5 py-4 tracking-wider text-right min-w-[120px]">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {filteredAndSortedLedger.length === 0 ? (
                           <tr>
                             <td colSpan={6} className="px-4 py-12 text-center text-slate-600">
                               <div className="flex flex-col items-center gap-2">
                                 <Database className="w-8 h-8 opacity-20" />
                                 <span className="italic">{ledger.length === 0 ? "Ledger is empty" : "No matching entries found"}</span>
                                </div>
                             </td>
                           </tr>
                        ) : (
                          filteredAndSortedLedger.map((entry) => (
                            <tr 
                              key={entry.id} 
                              className={getRowClassName(entry.id, replayStatus[entry.id])}
                              onClick={() => { setEnvelope(entry.envelope); setActiveTab('current'); }}
                            >
                              <td className="px-5 py-4">
                                {entry.envelope.status === 'SUCCESS' && <span className="inline-flex items-center gap-1.5 text-emerald-400 font-medium bg-emerald-500/5 px-2 py-0.5 rounded border border-emerald-500/10"><CheckCircleIcon /> Pass</span>}
                                {entry.envelope.status === 'FAILED_SCHEMA' && <span className="inline-flex items-center gap-1.5 text-rose-400 font-medium bg-rose-500/5 px-2 py-0.5 rounded border border-rose-500/10"><XCircleIcon /> Schema</span>}
                                {entry.envelope.status === 'FAILED_SEMANTIC' && <span className="inline-flex items-center gap-1.5 text-amber-400 font-medium bg-amber-500/5 px-2 py-0.5 rounded border border-amber-500/10"><AlertIcon /> Semantic</span>}
                              </td>
                              <td className="px-5 py-4 font-mono text-slate-500 group-hover:text-slate-300 transition-colors whitespace-nowrap">{new Date(entry.timestamp).toLocaleTimeString()}</td>
                              <td className="px-5 py-4 font-mono text-indigo-400/70 truncate max-w-[100px]" title={entry.envelope.trace_id}>{entry.envelope.trace_id.substring(0, 8)}...</td>
                              <td className="px-5 py-4 text-center font-mono">{entry.envelope.iterations}</td>
                              <td className="px-5 py-4 text-white font-medium">{entry.envelope.asset?.asset_type || '-'}</td>
                              <td className="px-5 py-4 text-right">
                                <div className="flex items-center justify-end gap-3">
                                  {replayStatus[entry.id] === 'success' && (
                                    <motion.span 
                                      initial={{ scale: 0.8, opacity: 0 }}
                                      animate={{ scale: 1, opacity: 1 }}
                                      className="flex items-center gap-1 text-emerald-400 text-[10px] font-bold uppercase tracking-wider"
                                    >
                                      <Check className="w-3.5 h-3.5" />
                                      Verified
                                    </motion.span>
                                  )}
                                  {replayStatus[entry.id] === 'error' && (
                                    <motion.span 
                                      initial={{ scale: 0.8, opacity: 0 }}
                                      animate={{ scale: 1, opacity: 1 }}
                                      className="flex items-center gap-1 text-rose-400 text-[10px] font-bold uppercase tracking-wider"
                                    >
                                      <AlertCircle className="w-3.5 h-3.5" />
                                      Corrupted
                                    </motion.span>
                                  )}
                                  <button
                                    onClick={(e) => handleReplay(e, entry)}
                                    disabled={replayingId === entry.id}
                                    className={`
                                      p-1.5 rounded-md transition-all border border-transparent
                                      ${replayingId === entry.id 
                                        ? 'bg-indigo-500/20 text-indigo-300 cursor-wait' 
                                        : 'hover:bg-white/10 hover:border-white/10 text-slate-500 hover:text-slate-200'
                                      }
                                    `}
                                    title="Replay Validation & Verify Integrity"
                                  >
                                    <RefreshCw className={`w-3.5 h-3.5 ${replayingId === entry.id ? 'animate-spin' : ''}`} />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
               </motion.div>
             )}
             </AnimatePresence>

           </div>
        </div>
      </main>
    </div>
  );
}

const MetricCard = ({ label, value, fontMono, highlight }: { label: string, value: string | number | undefined, fontMono?: boolean, highlight?: boolean }) => (
  <div className={`
    bg-slate-900/50 border border-white/5 p-4 rounded-xl flex flex-col justify-between h-20 transition-all hover:border-white/10
    ${highlight ? 'bg-indigo-500/5 border-indigo-500/20' : ''}
  `}>
    <div className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">{label}</div>
    <div className={`text-sm text-slate-200 ${fontMono ? 'font-mono' : 'font-medium'} ${highlight ? 'text-indigo-300' : ''}`}>
      {value}
    </div>
  </div>
);

// Mini icon helpers
const CheckCircleIcon = () => <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]"></div>;
const XCircleIcon = () => <div className="w-1.5 h-1.5 rounded-full bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.5)]"></div>;
const AlertIcon = () => <div className="w-1.5 h-1.5 rounded-full bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.5)]"></div>;