import React, { KeyboardEvent } from 'react';
import { Undo2, Redo2 } from 'lucide-react';

interface JsonEditorProps {
  value: string;
  onChange: (val: string) => void;
  label?: string;
  readOnly?: boolean;
  onUndo?: () => void;
  onRedo?: () => void;
  canUndo?: boolean;
  canRedo?: boolean;
}

export const JsonEditor: React.FC<JsonEditorProps> = ({ 
  value, 
  onChange, 
  label, 
  readOnly = false,
  onUndo,
  onRedo,
  canUndo = false,
  canRedo = false
}) => {

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (readOnly) return;
    
    const isCtrlOrCmd = e.ctrlKey || e.metaKey;
    const key = e.key.toLowerCase();
    
    // Undo: Ctrl+Z or Cmd+Z
    // Redo: Ctrl+Shift+Z or Ctrl+Y or Cmd+Shift+Z or Cmd+Y

    if (isCtrlOrCmd) {
      if (key === 'z') {
        e.preventDefault();
        if (e.shiftKey) {
          onRedo?.();
        } else {
          onUndo?.();
        }
      } else if (key === 'y') {
        e.preventDefault();
        onRedo?.();
      }
    }
  };

  return (
    <div className="flex flex-col h-full font-mono text-sm bg-[#0d1117] relative">
      {label && (
        <div className="bg-[#161b22] px-4 py-2 border-b border-white/5 flex justify-between items-center select-none">
          <span className="text-slate-400 font-semibold text-xs uppercase tracking-wider">{label}</span>
          
          <div className="flex items-center gap-2">
            {!readOnly && (
              <div className="flex items-center gap-1 mr-2 border-r border-white/5 pr-2">
                <button
                  onClick={onUndo}
                  disabled={!canUndo}
                  className={`p-1 rounded hover:bg-white/10 transition-colors ${!canUndo ? 'opacity-30 cursor-not-allowed' : 'text-slate-400 hover:text-white'}`}
                  title="Undo (Ctrl+Z)"
                >
                  <Undo2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={onRedo}
                  disabled={!canRedo}
                  className={`p-1 rounded hover:bg-white/10 transition-colors ${!canRedo ? 'opacity-30 cursor-not-allowed' : 'text-slate-400 hover:text-white'}`}
                  title="Redo (Ctrl+Shift+Z)"
                >
                  <Redo2 className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
            {readOnly && <span className="text-[10px] text-slate-600 font-medium bg-slate-800 px-2 py-0.5 rounded">READ ONLY</span>}
          </div>
        </div>
      )}
      <textarea
        className={`flex-1 p-5 bg-[#0d1117] text-slate-300 resize-none outline-none custom-scrollbar w-full leading-relaxed ${readOnly ? 'opacity-90' : ''}`}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={handleKeyDown}
        readOnly={readOnly}
        spellCheck={false}
        placeholder={readOnly ? "// Output will appear here..." : "// Paste JSON asset definition here..."}
        style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '13px' }}
      />
      
      {/* Footer status bar decoration */}
      <div className="h-6 bg-[#161b22] border-t border-white/5 flex items-center px-4 justify-end gap-4 text-[10px] text-slate-600 select-none">
         <span>UTF-8</span>
         <span>JSON</span>
         <span>{value.split('\n').length} lines</span>
      </div>
    </div>
  );
};
