import React, { useState, useEffect, useCallback } from 'react';
import { Undo2, Redo2, Trash2, Activity } from 'lucide-react';
import { AssetData, HistoryRecord, ValidationResult } from './types';
import { validateAsset, generateTraceId } from './utils';
import SchemaCard from './components/SchemaCard';
import InputCard from './components/InputCard';
import ResultCard from './components/ResultCard';
import HistoryCard from './components/HistoryCard';
import { ReplayModal, UrlModal } from './components/Modals';

const App: React.FC = () => {
  // State
  const [jsonInput, setJsonInput] = useState<string>('');
  const [validationResult, setValidationResult] = useState<ValidationResult | null>(null);
  const [history, setHistory] = useState<HistoryRecord[]>([]);
  const [isValidating, setIsValidating] = useState(false);
  
  // Modals
  const [isReplayOpen, setIsReplayOpen] = useState(false);
  const [replayRecord, setReplayRecord] = useState<HistoryRecord | null>(null);
  const [isUrlModalOpen, setIsUrlModalOpen] = useState(false);

  // Load history from local storage on mount
  useEffect(() => {
    const saved = localStorage.getItem('compliance_history');
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load history", e);
      }
    }
  }, []);

  // Save history on change
  useEffect(() => {
    localStorage.setItem('compliance_history', JSON.stringify(history));
  }, [history]);

  const handleValidate = useCallback(async () => {
    if (!jsonInput.trim()) {
      setValidationResult({
        valid: false,
        type: 'schema',
        message: "No Input Provided",
        details: "Please enter JSON data to validate"
      });
      return;
    }

    setIsValidating(true);
    
    // Simulate slight network delay for effect
    await new Promise(resolve => setTimeout(resolve, 600));

    let assetData: AssetData;
    try {
      assetData = JSON.parse(jsonInput);
    } catch (e: any) {
      setValidationResult({
        valid: false,
        type: 'schema',
        message: "Invalid JSON Format",
        details: `Parse error: ${e.message}`
      });
      setIsValidating(false);
      return;
    }

    const result = validateAsset(assetData);
    setValidationResult(result);

    const newRecord: HistoryRecord = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date().toISOString(),
      asset_id: assetData.asset_id || 'N/A',
      trace_id: generateTraceId(),
      iters: Math.floor(Math.random() * 5) + 1,
      result: result.type,
      details: result.message
    };

    setHistory(prev => [newRecord, ...prev].slice(0, 999)); // Keep last 999
    setIsValidating(false);
  }, [jsonInput]);

  const handleClearHistory = () => {
    if (window.confirm("Are you sure you want to clear all validation history?")) {
      setHistory([]);
      setValidationResult(null);
    }
  };

  const handleConversionResult = (success: boolean, msg: string) => {
    setValidationResult({
      valid: success,
      type: success ? 'valid' : 'schema',
      message: success ? "Conversion Successful" : "Conversion Failed",
      details: msg
    });
  };

  const handleUrlFetch = async (url: string) => {
    try {
      const response = await fetch(url);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const text = await response.text();
      
      // Try parsing to ensure valid JSON before setting
      JSON.parse(text); 
      setJsonInput(text); // If success, format it later via component if needed, or leave raw
      
      setValidationResult({
        valid: true,
        type: 'valid',
        message: "Data Fetched",
        details: "Successfully loaded data from URL. Click 'Validate' to check compliance."
      });
      setIsUrlModalOpen(false);
    } catch (e: any) {
      setValidationResult({
        valid: false,
        type: 'schema',
        message: "Fetch Failed",
        details: e.message
      });
      // Don't close modal on error so user can fix URL
    }
  };

  const handleExport = () => {
    if (history.length === 0) return;
    const dataStr = JSON.stringify({
      exported_at: new Date().toISOString(),
      total_records: history.length,
      ledger: history
    }, null, 2);
    
    const blob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `validation-ledger-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const openReplay = (record: HistoryRecord) => {
    setReplayRecord(record);
    setIsReplayOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-gray-100 font-sans selection:bg-indigo-500/30">
      <div className="container mx-auto p-6 max-w-7xl">
        {/* Header */}
        <header className="bg-slate-800 border-b-2 border-indigo-500 rounded-lg p-5 mb-8 flex flex-col md:flex-row justify-between items-center gap-4 shadow-lg">
          <div>
            <h1 className="text-2xl font-bold text-indigo-400 tracking-tight">Blueprint Compliance Engine</h1>
            <p className="text-xs text-slate-400 font-medium tracking-wide">Hackathon Demo Module</p>
          </div>
          <div className="flex items-center gap-3">
             <div className="flex gap-2 mr-4">
               <button disabled className="p-2 rounded bg-slate-700 text-slate-500 cursor-not-allowed hover:bg-slate-600 transition"><Undo2 className="w-4 h-4" /> </button>
               <button disabled className="p-2 rounded bg-slate-700 text-slate-500 cursor-not-allowed hover:bg-slate-600 transition"><Redo2 className="w-4 h-4" /></button>
             </div>
             <button 
               onClick={handleClearHistory}
               className="px-4 py-2 bg-red-600/10 hover:bg-red-600 text-red-500 hover:text-white border border-red-600/20 rounded-md text-sm font-medium transition-all flex items-center gap-2"
             >
               <Trash2 className="w-4 h-4" /> Clear History
             </button>
             <div className="flex items-center gap-2 px-4 py-2 bg-slate-900 rounded-md border border-slate-700">
               <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.6)]" />
               <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider">System Ready</span>
             </div>
          </div>
        </header>

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Column */}
          <div className="flex flex-col">
            <SchemaCard />
            <InputCard 
              input={jsonInput} 
              setInput={setJsonInput} 
              onValidate={handleValidate} 
              onOpenUrlModal={() => setIsUrlModalOpen(true)}
              onConversionResult={handleConversionResult}
              isValidating={isValidating}
            />
          </div>

          {/* Right Column */}
          <div className="flex flex-col">
            <ResultCard result={validationResult} />
            <HistoryCard 
              history={history} 
              onReplay={openReplay}
              onExport={handleExport}
            />
          </div>
        </div>

        {/* Modals */}
        <ReplayModal 
          isOpen={isReplayOpen} 
          onClose={() => setIsReplayOpen(false)} 
          record={replayRecord} 
        />
        <UrlModal 
          isOpen={isUrlModalOpen} 
          onClose={() => setIsUrlModalOpen(false)} 
          onFetch={handleUrlFetch} 
        />
      </div>
    </div>
  );
};

export default App;