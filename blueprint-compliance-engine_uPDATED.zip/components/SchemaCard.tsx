import React from 'react';
import { ClipboardList } from 'lucide-react';

const SchemaCard: React.FC = () => {
  return (
    <div className="bg-slate-800 border border-slate-700 rounded-xl p-6 mb-6 shadow-sm">
      <div className="flex items-center gap-3 mb-5 pb-4 border-b border-slate-700">
        <ClipboardList className="w-6 h-6 text-indigo-400" />
        <div className="flex-1">
          <h2 className="text-lg font-semibold text-gray-100">FIBO Asset Schema</h2>
          <p className="text-xs text-gray-400">Version: v1.0</p>
        </div>
      </div>
      <ul className="space-y-2">
        {[
          "asset_id: string (min 5 chars, uppercase)",
          "asset_type: Stock | Bond | Derivative | FX",
          "issuer_name: string (min 5 chars)",
          "is_fiat_denominated: boolean",
          "price: number (> 0)",
          "required_documentation: array of strings"
        ].map((rule, idx) => (
          <li key={idx} className="p-3 bg-slate-900 rounded-md text-sm font-mono text-emerald-400 flex items-start gap-2">
            <span className="mt-0.5">✓</span>
            <span>{rule}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default SchemaCard;