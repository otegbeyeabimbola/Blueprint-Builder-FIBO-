import React from 'react';
import { Target } from 'lucide-react';
import { ValidationResult } from '../types';

interface ResultCardProps {
  result: ValidationResult | null;
}

const ResultCard: React.FC<ResultCardProps> = ({ result }) => {
  if (!result) {
    return (
      <div className="bg-slate-800 border border-slate-700 rounded-xl p-6 mb-6 shadow-sm min-h-[200px] flex flex-col">
         <div className="flex items-center gap-3 mb-5 pb-4 border-b border-slate-700">
          <Target className="w-6 h-6 text-indigo-400" />
          <h2 className="text-lg font-semibold text-gray-100">Validation Result</h2>
        </div>
        <div className="flex-1 flex items-center justify-center text-slate-500">
          Run a validation to see results here
        </div>
      </div>
    );
  }

  let badgeColorClass = "";
  let badgeText = "";
  
  switch (result.type) {
    case 'valid':
      badgeColorClass = "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30";
      badgeText = "✅ VALID";
      break;
    case 'semantic':
      badgeColorClass = "bg-orange-500/20 text-orange-400 border border-orange-500/30";
      badgeText = "⚠️ SEMANTIC FAIL";
      break;
    case 'schema':
      badgeColorClass = "bg-red-500/20 text-red-400 border border-red-500/30";
      badgeText = "🚫 SCHEMA FAIL";
      break;
  }

  return (
    <div className="bg-slate-800 border border-slate-700 rounded-xl p-6 mb-6 shadow-sm min-h-[200px]">
      <div className="flex items-center gap-3 mb-5 pb-4 border-b border-slate-700">
        <Target className="w-6 h-6 text-indigo-400" />
        <h2 className="text-lg font-semibold text-gray-100">Validation Result</h2>
      </div>
      
      <div className="animate-fade-in">
        <span className={`inline-block px-3 py-1.5 rounded-md text-xs font-bold mb-4 ${badgeColorClass}`}>
          {badgeText}
        </span>
        
        <div className="bg-indigo-500/10 border-l-4 border-indigo-500 p-4 rounded-r-md">
          <p className="font-semibold text-gray-200 text-sm mb-3">{result.message}</p>
          <div className="text-gray-400 text-sm space-y-1">
            {result.details.split('\n').map((line, idx) => (
              <p key={idx} className="leading-relaxed">
                {line.startsWith('•') ? line : `• ${line}`}
              </p>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResultCard;