import React, { useRef } from 'react';
import { Edit3, CheckCircle, AlertTriangle, AlertOctagon, Search, Upload, RefreshCw, Globe, FileJson } from 'lucide-react';
import { SAMPLES } from '../types';
import { convertRawToJSON } from '../utils';

interface InputCardProps {
  input: string;
  setInput: (val: string) => void;
  onValidate: () => void;
  onOpenUrlModal: () => void;
  onConversionResult: (success: boolean, msg: string) => void;
  isValidating: boolean;
}

const InputCard: React.FC<InputCardProps> = ({ 
  input, 
  setInput, 
  onValidate, 
  onOpenUrlModal, 
  onConversionResult,
  isValidating 
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const loadSample = (type: keyof typeof SAMPLES) => {
    setInput(JSON.stringify(SAMPLES[type], null, 2));
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        setInput(JSON.stringify(json, null, 2));
        onConversionResult(true, `File "${file.name}" imported successfully.`);
      } catch (err) {
        onConversionResult(false, "Failed to parse JSON file.");
      }
      if (fileInputRef.current) fileInputRef.current.value = '';
    };
    reader.readAsText(file);
  };

  const handleConvert = () => {
    const result = convertRawToJSON(input);
    if (result.success && result.data) {
      setInput(JSON.stringify(result.data, null, 2));
      onConversionResult(true, "Successfully converted raw data to JSON.");
    } else {
      onConversionResult(false, result.message || "Conversion failed.");
    }
  };

  return (
    <div className="bg-slate-800 border border-slate-700 rounded-xl p-6 mb-6 shadow-sm">
      <div className="flex items-center gap-3 mb-5 pb-4 border-b border-slate-700">
        <Edit3 className="w-6 h-6 text-indigo-400" />
        <h2 className="text-lg font-semibold text-gray-100">Test JSON Input</h2>
      </div>

      <div className="flex gap-3 mb-4">
        <button 
          onClick={() => loadSample('valid')}
          className="flex-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md text-xs font-medium transition-colors flex items-center justify-center gap-2"
        >
          <CheckCircle className="w-3 h-3" /> Valid Asset
        </button>
        <button 
          onClick={() => loadSample('semantic')}
          className="flex-1 py-2 px-3 bg-orange-600 hover:bg-orange-700 text-white rounded-md text-xs font-medium transition-colors flex items-center justify-center gap-2"
        >
          <AlertTriangle className="w-3 h-3" /> Semantic Fail
        </button>
        <button 
          onClick={() => loadSample('schema')}
          className="flex-1 py-2 px-3 bg-red-600 hover:bg-red-700 text-white rounded-md text-xs font-medium transition-colors flex items-center justify-center gap-2"
        >
          <AlertOctagon className="w-3 h-3" /> Schema Fail
        </button>
      </div>

      <textarea 
        value={input}
        onChange={(e) => setInput(e.target.value)}
        className="w-full min-h-[240px] bg-slate-900 border border-slate-700 rounded-lg p-4 text-gray-300 font-mono text-sm resize-y mb-4 focus:outline-none focus:border-indigo-500 transition-colors"
        placeholder='{ "asset_id": "STOCK123", "asset_type": "Stock", ... }'
      />

      <div className="flex gap-3 mb-3">
        <button 
          onClick={onValidate}
          disabled={isValidating}
          className="flex-1 py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-70 disabled:cursor-not-allowed text-white rounded-md text-sm font-medium transition-colors flex items-center justify-center gap-2"
        >
          {isValidating ? (
             <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : (
            <Search className="w-4 h-4" />
          )}
          {isValidating ? 'Validating...' : 'Validate Asset'}
        </button>
        <button 
          onClick={() => loadSample('valid')}
          className="flex-1 py-2.5 px-4 bg-slate-700 hover:bg-slate-600 text-gray-200 rounded-md text-sm font-medium transition-colors"
        >
          Load Sample
        </button>
      </div>

      <div className="flex gap-3">
        <button 
          onClick={() => fileInputRef.current?.click()}
          className="flex-1 py-2 px-3 bg-slate-700 hover:bg-slate-600 text-gray-300 rounded-md text-xs font-medium transition-colors flex items-center justify-center gap-2"
        >
          <Upload className="w-3 h-3" /> Import JSON
        </button>
        <input 
          type="file" 
          accept=".json" 
          ref={fileInputRef} 
          className="hidden" 
          onChange={handleFileUpload}
        />
        
        <button 
          onClick={handleConvert}
          className="flex-1 py-2 px-3 bg-slate-700 hover:bg-slate-600 text-gray-300 rounded-md text-xs font-medium transition-colors flex items-center justify-center gap-2"
        >
          <RefreshCw className="w-3 h-3" /> Convert Data
        </button>
        
        <button 
          onClick={onOpenUrlModal}
          className="flex-1 py-2 px-3 bg-slate-700 hover:bg-slate-600 text-gray-300 rounded-md text-xs font-medium transition-colors flex items-center justify-center gap-2"
        >
          <Globe className="w-3 h-3" /> Fetch URL
        </button>
      </div>
    </div>
  );
};

export default InputCard;