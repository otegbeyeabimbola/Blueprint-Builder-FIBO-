import React, { useState, useMemo } from 'react';
import { BarChart2, Search, Filter, Download, Play, ChevronDown, CheckCircle, AlertTriangle, AlertOctagon } from 'lucide-react';
import { HistoryRecord } from '../types';

interface HistoryCardProps {
  history: HistoryRecord[];
  onReplay: (record: HistoryRecord) => void;
  onExport: () => void;
}

const HistoryCard: React.FC<HistoryCardProps> = ({ history, onReplay, onExport }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sortFilter, setSortFilter] = useState<string>('timestamp');
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  // Close filter dropdown when clicking outside
  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (!target.closest('.filter-container')) {
        setIsFilterOpen(false);
      }
    };
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  const filteredHistory = useMemo(() => {
    return history
      .filter(record => {
        const matchesSearch = record.asset_id.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesStatus = statusFilter === 'all' || record.result === statusFilter;
        return matchesSearch && matchesStatus;
      })
      .sort((a, b) => {
        switch (sortFilter) {
          case 'timestamp': return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
          case 'asset_id': return a.asset_id.localeCompare(b.asset_id);
          case 'trace_id': return a.trace_id.localeCompare(b.trace_id);
          case 'type': return a.result.localeCompare(b.result);
          default: return 0;
        }
      });
  }, [history, searchTerm, statusFilter, sortFilter]);

  const getResultIcon = (result: string) => {
    switch(result) {
      case 'valid': return <CheckCircle className="w-4 h-4 text-emerald-500" />;
      case 'semantic': return <AlertTriangle className="w-4 h-4 text-orange-500" />;
      case 'schema': return <AlertOctagon className="w-4 h-4 text-red-500" />;
      default: return null;
    }
  };

  return (
    <div className="bg-slate-800 border border-slate-700 rounded-xl p-6 shadow-sm flex flex-col h-full min-h-[500px]">
      <div className="flex items-center justify-between mb-5 pb-4 border-b border-slate-700">
        <div className="flex items-center gap-3">
          <BarChart2 className="w-6 h-6 text-indigo-400" />
          <div>
            <h2 className="text-lg font-semibold text-gray-100">Validation History</h2>
            <p className="text-xs text-gray-400">{history.length} validations</p>
          </div>
        </div>
        <button 
          onClick={onExport}
          className="py-2 px-3 bg-slate-700 hover:bg-slate-600 text-gray-200 rounded-md text-xs font-medium transition-colors flex items-center gap-2"
        >
          <Download className="w-3 h-3" /> Export Ledger
        </button>
      </div>

      <div className="flex gap-3 mb-4">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input 
            type="text" 
            placeholder="Search by Asset ID..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900 border border-slate-700 rounded-lg py-2.5 pl-10 pr-4 text-sm text-gray-200 focus:outline-none focus:border-indigo-500 transition-colors placeholder:text-slate-500"
          />
        </div>
        
        <div className="relative filter-container">
          <button 
            onClick={(e) => { e.stopPropagation(); setIsFilterOpen(!isFilterOpen); }}
            className={`h-full px-4 border border-slate-700 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors ${isFilterOpen ? 'bg-indigo-600 border-indigo-500 text-white' : 'bg-slate-700 text-gray-200 hover:bg-slate-600'}`}
          >
            <Filter className="w-4 h-4" /> Filter <ChevronDown className="w-3 h-3" />
          </button>
          
          {isFilterOpen && (
            <div className="absolute right-0 top-full mt-2 w-60 bg-slate-800 border border-slate-700 rounded-xl shadow-xl z-50 p-2 animate-in fade-in zoom-in-95 duration-100">
              <div className="px-3 py-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Filter by Status</div>
              {['all', 'valid', 'semantic', 'schema'].map(opt => (
                <div 
                  key={opt}
                  onClick={() => setStatusFilter(opt)}
                  className={`flex items-center gap-3 px-3 py-2 rounded-md cursor-pointer text-sm ${statusFilter === opt ? 'bg-indigo-600 text-white' : 'text-gray-300 hover:bg-slate-700'}`}
                >
                  <div className={`w-4 h-4 border-2 rounded flex items-center justify-center ${statusFilter === opt ? 'bg-white border-white' : 'border-slate-500'}`}>
                    {statusFilter === opt && <div className="w-2 h-2 bg-indigo-600 rounded-sm" />}
                  </div>
                  <span className="capitalize">{opt === 'all' ? 'All Status' : opt}</span>
                </div>
              ))}
              
              <div className="h-px bg-slate-700 my-2" />
              
              <div className="px-3 py-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Sort By</div>
              {[
                { val: 'timestamp', label: 'Timestamp (Newest)' },
                { val: 'asset_id', label: 'Asset ID (A-Z)' },
                { val: 'trace_id', label: 'Trace ID (A-Z)' },
                { val: 'type', label: 'Type (A-Z)' }
              ].map(opt => (
                <div 
                  key={opt.val}
                  onClick={() => setSortFilter(opt.val)}
                  className={`flex items-center gap-3 px-3 py-2 rounded-md cursor-pointer text-sm ${sortFilter === opt.val ? 'bg-indigo-600 text-white' : 'text-gray-300 hover:bg-slate-700'}`}
                >
                   <div className={`w-4 h-4 border-2 rounded flex items-center justify-center ${sortFilter === opt.val ? 'bg-white border-white' : 'border-slate-500'}`}>
                    {sortFilter === opt.val && <div className="w-2 h-2 bg-indigo-600 rounded-sm" />}
                  </div>
                  <span>{opt.label}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-auto -mx-2 px-2">
        {filteredHistory.length === 0 ? (
          <div className="h-40 flex items-center justify-center text-slate-500 text-sm">
            No validation history found
          </div>
        ) : (
          <table className="w-full text-left border-collapse">
            <thead className="sticky top-0 bg-slate-800 z-10 shadow-sm">
              <tr>
                <th className="py-3 px-2 text-xs font-semibold text-slate-400 uppercase border-b border-slate-700">Status</th>
                <th className="py-3 px-2 text-xs font-semibold text-slate-400 uppercase border-b border-slate-700">Timestamp</th>
                <th className="py-3 px-2 text-xs font-semibold text-slate-400 uppercase border-b border-slate-700">Asset ID</th>
                <th className="py-3 px-2 text-xs font-semibold text-slate-400 uppercase border-b border-slate-700 hidden sm:table-cell">Trace ID</th>
                <th className="py-3 px-2 text-xs font-semibold text-slate-400 uppercase border-b border-slate-700">Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredHistory.map(record => (
                <tr key={record.id} className="border-b border-slate-700/50 hover:bg-slate-700/30 transition-colors group">
                  <td className="py-3 px-2">
                    <div className="flex items-center gap-2">
                      {getResultIcon(record.result)}
                      <span className={`text-xs font-medium uppercase ${
                        record.result === 'valid' ? 'text-emerald-400' : 
                        record.result === 'semantic' ? 'text-orange-400' : 'text-red-400'
                      }`}>
                        {record.result}
                      </span>
                    </div>
                  </td>
                  <td className="py-3 px-2 text-xs text-gray-400">
                    {new Date(record.timestamp).toLocaleTimeString()}
                  </td>
                  <td className="py-3 px-2 text-xs font-mono text-indigo-400">
                    {record.asset_id}
                  </td>
                  <td className="py-3 px-2 text-xs font-mono text-slate-500 hidden sm:table-cell">
                    {record.trace_id}
                  </td>
                  <td className="py-3 px-2">
                    <button 
                      onClick={() => onReplay(record)}
                      className="text-xs bg-indigo-600/10 hover:bg-indigo-600 text-indigo-400 hover:text-white py-1 px-2 rounded transition-all flex items-center gap-1 opacity-0 group-hover:opacity-100 focus:opacity-100"
                    >
                      <Play className="w-3 h-3" /> Replay
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default HistoryCard;