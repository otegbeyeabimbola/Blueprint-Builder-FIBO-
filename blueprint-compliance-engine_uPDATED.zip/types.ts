export interface AssetData {
  asset_id?: string;
  asset_type?: string;
  issuer_name?: string | number;
  is_fiat_denominated?: boolean;
  price?: number;
  required_documentation?: string[] | string;
  [key: string]: any;
}

export type ValidationStatus = 'valid' | 'semantic' | 'schema';

export interface ValidationResult {
  valid: boolean;
  type: ValidationStatus;
  message: string;
  details: string;
}

export interface HistoryRecord {
  id: string; // Unique ID for keying
  timestamp: string;
  asset_id: string;
  trace_id: string;
  iters: number;
  result: ValidationStatus;
  details: string;
}

export const SAMPLES = {
  valid: {
    asset_id: "STOCK123",
    asset_type: "Stock",
    issuer_name: "TechCorp Industries",
    is_fiat_denominated: true,
    price: 150.75,
    required_documentation: ["Prospectus", "Annual Report"]
  },
  semantic: {
    asset_id: "BOND456",
    asset_type: "Bond",
    issuer_name: "Government Corp",
    is_fiat_denominated: true,
    price: 1000,
    required_documentation: ["Prospectus"]
  },
  schema: {
    asset_id: "STK",
    asset_type: "Cryptocurrency",
    issuer_name: 12345,
    price: -50,
    required_documentation: "Not an array"
  }
};