import { AssetData, ValidationResult } from './types';

export const generateTraceId = () => 'TRC-' + Math.random().toString(36).substr(2, 9).toUpperCase();

export function validateAsset(assetData: AssetData): ValidationResult {
  const errors: string[] = [];
  
  // Schema validation
  if (!assetData.asset_id || typeof assetData.asset_id !== 'string') {
    errors.push("asset_id is required and must be a string");
  } else if (assetData.asset_id.length < 5) {
    errors.push("asset_id must be at least 5 characters");
  } else if (assetData.asset_id !== assetData.asset_id.toUpperCase()) {
    errors.push("asset_id must be uppercase");
  }

  const validTypes = ["Stock", "Bond", "Derivative", "FX"];
  if (!validTypes.includes(assetData.asset_type as string)) {
    errors.push("asset_type must be one of: Stock, Bond, Derivative, FX");
  }

  if (!assetData.issuer_name || typeof assetData.issuer_name !== 'string') {
    errors.push("issuer_name is required and must be a string");
  } else if (assetData.issuer_name.length < 5) {
    errors.push("issuer_name must be at least 5 characters");
  }

  if (typeof assetData.is_fiat_denominated !== 'boolean') {
    errors.push("is_fiat_denominated must be a boolean");
  }

  if (typeof assetData.price !== 'number' || assetData.price <= 0) {
    errors.push("price must be a positive number");
  }

  if (!Array.isArray(assetData.required_documentation)) {
    errors.push("required_documentation must be an array");
  } else if (assetData.required_documentation.length === 0) {
    errors.push("required_documentation array cannot be empty");
  }

  if (errors.length > 0) {
    return {
      valid: false,
      type: 'schema',
      message: "Schema Validation Failed",
      details: errors.join("\n• ")
    };
  }

  // Semantic validation - business rules
  const semanticErrors: string[] = [];
  
  // Check if Bond has appropriate pricing (bonds typically trade near face value)
  if (assetData.asset_type === "Bond" && (assetData.price as number) < 50) {
    semanticErrors.push("Bond price is unusually low (below 50)");
  }
  
  // Check if issuer name seems too generic or abbreviated
  if ((assetData.issuer_name as string).length < 10) {
    semanticErrors.push("Issuer name appears too short or generic for regulatory compliance");
  }
  
  // Check if required documentation is minimal
  if ((assetData.required_documentation as string[]).length < 2) {
    semanticErrors.push("Insufficient documentation for regulatory standards (minimum 2 required)");
  }

  if (semanticErrors.length > 0) {
    return {
      valid: false,
      type: 'semantic',
      message: "Semantic Validation Failed",
      details: semanticErrors.join("\n• ")
    };
  }

  return {
    valid: true,
    type: 'valid',
    message: "✅ All Validations Passed",
    details: "Asset meets all FIBO schema requirements and semantic rules."
  };
}

export function convertRawToJSON(input: string): { success: boolean; data?: any; message?: string } {
  const trimmedInput = input.trim();
  
  if (!trimmedInput) return { success: false, message: "Empty input" };

  try {
    // Try standard JSON parse first
    const parsed = JSON.parse(trimmedInput);
    return { success: true, data: parsed };
  } catch (e) {
    // Continue to custom parsing
  }

  const converted: any = {};
  let conversionSuccess = false;

  // Strategy 1: Line by line parsing
  const lines = trimmedInput.split('\n').filter(line => line.trim());
  
  for (const line of lines) {
    const colonMatch = line.match(/^\s*["']?(\w+)["']?\s*:\s*(.+)$/);
    const equalsMatch = line.match(/^\s*["']?(\w+)["']?\s*=\s*(.+)$/);
    
    const match = colonMatch || equalsMatch;
    
    if (match) {
      conversionSuccess = true;
      const key = match[1].trim();
      let value = match[2].trim();
      
      value = value.replace(/[,;]\s*$/, '');
      
      if ((value.startsWith('"') && value.endsWith('"')) || 
          (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      
      parseValue(key, value, converted);
    }
  }

  // Strategy 2: Comma separated parsing if strategy 1 failed or yielded no results but commas exist
  if ((!conversionSuccess || Object.keys(converted).length === 0) && trimmedInput.includes(',')) {
    const pairs = trimmedInput.split(',');
    for (const pair of pairs) {
      const colonMatch = pair.match(/^\s*["']?(\w+)["']?\s*:\s*(.+)$/);
      const equalsMatch = pair.match(/^\s*["']?(\w+)["']?\s*=\s*(.+)$/);
      
      const match = colonMatch || equalsMatch;
      
      if (match) {
        conversionSuccess = true;
        const key = match[1].trim();
        let value = match[2].trim();
        
        if ((value.startsWith('"') && value.endsWith('"')) || 
            (value.startsWith("'") && value.endsWith("'"))) {
          value = value.slice(1, -1);
        }
        
        parseValue(key, value, converted);
      }
    }
  }

  if (conversionSuccess && Object.keys(converted).length > 0) {
    return { success: true, data: converted };
  }

  return { success: false, message: "Could not parse format" };
}

function parseValue(key: string, value: string, targetObj: any) {
  if (value === 'true') {
    targetObj[key] = true;
  } else if (value === 'false') {
    targetObj[key] = false;
  } else if (value === 'null') {
    targetObj[key] = null;
  } else if (!isNaN(Number(value)) && value !== '') {
    targetObj[key] = parseFloat(value);
  } else if (value.startsWith('[') && value.endsWith(']')) {
    try {
      targetObj[key] = JSON.parse(value);
    } catch {
      targetObj[key] = value;
    }
  } else {
    targetObj[key] = value;
  }
}