import React from 'react';
import { Status } from '../types';
import { CheckCircle2, AlertTriangle, XCircle, Loader2 } from 'lucide-react';

export const StatusBadge: React.FC<{ status: Status; isRunning?: boolean }> = ({ status, isRunning }) => {
  if (isRunning) {
    return (
      <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 shadow-[0_0_10px_rgba(59,130,246,0.2)]">
        <Loader2 className="w-4 h-4 text-blue-400 animate-spin" />
        <span className="text-xs font-medium text-blue-300 tracking-wide">PROCESSING</span>
      </div>
    );
  }

  switch (status) {
    case 'SUCCESS':
      return (
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 shadow-[0_0_15px_rgba(16,185,129,0.25)]">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-bold text-emerald-300 tracking-wide shadow-black drop-shadow-sm">VERIFIED COMPLIANT</span>
        </div>
      );
    case 'FAILED_SEMANTIC':
      return (
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/20 shadow-[0_0_15px_rgba(245,158,11,0.2)]">
          <AlertTriangle className="w-4 h-4 text-amber-400" />
          <span className="text-xs font-bold text-amber-300 tracking-wide">SEMANTIC VIOLATION</span>
        </div>
      );
    case 'FAILED_SCHEMA':
      return (
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-rose-500/10 border border-rose-500/20 shadow-[0_0_15px_rgba(244,63,94,0.25)]">
          <XCircle className="w-4 h-4 text-rose-400" />
          <span className="text-xs font-bold text-rose-300 tracking-wide">SCHEMA VIOLATION</span>
        </div>
      );
    default:
      return null;
  }
};