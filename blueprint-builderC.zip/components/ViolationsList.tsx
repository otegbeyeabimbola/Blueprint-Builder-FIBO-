import React from 'react';
import { Violation } from '../types';
import { AlertOctagon, AlertTriangle, Wrench, ArrowRight } from 'lucide-react';

interface ViolationsListProps {
  violations: Violation[];
}

export const ViolationsList: React.FC<ViolationsListProps> = ({ violations }) => {
  if (violations.length === 0) return null;

  return (
    <div className="flex flex-col gap-3">
      {violations.map((v, idx) => (
        <div 
          key={idx} 
          className="group relative overflow-hidden rounded-lg bg-slate-900/40 border border-white/5 p-4 hover:bg-slate-800/60 hover:border-white/10 transition-all duration-300"
        >
          {/* Accent Border Line */}
          <div className={`absolute left-0 top-0 bottom-0 w-1 ${v.category.includes('SEMANTIC') ? 'bg-amber-500' : 'bg-rose-500'}`} />
          
          <div className="flex gap-4 pl-2">
            <div className="mt-1 shrink-0">
              {v.category.includes('SEMANTIC') ? (
                <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 shadow-[0_0_10px_rgba(245,158,11,0.1)]">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                </div>
              ) : (
                <div className="p-2 rounded-lg bg-rose-500/10 border border-rose-500/20 shadow-[0_0_10px_rgba(244,63,94,0.1)]">
                  <AlertOctagon className="w-4 h-4 text-rose-400" />
                </div>
              )}
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-1.5">
                <span className="text-sm font-bold text-slate-200 tracking-tight">{v.type}</span>
                <span className="text-[10px] font-mono text-slate-500 bg-slate-950/50 px-2 py-0.5 rounded border border-white/5 truncate max-w-full sm:max-w-[200px]">
                  {v.field}
                </span>
              </div>
              
              <p className="text-xs text-slate-400 leading-relaxed mb-3">
                {v.description}
              </p>
              
              <div className="flex items-center gap-2 text-xs font-medium text-indigo-300 bg-indigo-500/10 px-3 py-2 rounded-md border border-indigo-500/20 w-fit">
                <Wrench className="w-3.5 h-3.5 text-indigo-400" />
                <span className="opacity-50 mx-1">|</span>
                <span>{v.fix_suggestion}</span>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};