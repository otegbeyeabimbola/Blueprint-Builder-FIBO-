export type AssetType = "Stock" | "Bond" | "Derivative" | "FX";
export type Currency = "USD" | "EUR" | "GBP";

export interface FiboAsset {
  asset_id: string;
  asset_type: AssetType;
  issuer_name: string;
  is_fiat_denominated: boolean;
  currency?: Currency | null;
  price: number;
  maturity_date?: string | null; // ISO Date string YYYY-MM-DD
  required_documentation: string[];
}

export type Status = "SUCCESS" | "FAILED_SCHEMA" | "FAILED_SEMANTIC";

export interface Violation {
  category: "SCHEMA_VIOLATION" | "SEMANTIC_VIOLATION" | "CRITICAL_PARSING_ERROR";
  type: string;
  field: string;
  description: string;
  fix_suggestion: string;
}

export interface ComplianceEnvelope {
  blueprint_version: string;
  status: Status;
  exit_code: 0 | 1 | 2 | 3;
  trace_id: string;
  canonical_json: string;
  violations_history: Violation[];
  last_violations: Violation[];
  iterations: int;
  was_corrected_by_patcher: boolean;
  asset: Partial<FiboAsset> | null;
  timestamp: string; // Added for frontend ledger
}

export type int = number;

export interface LedgerEntry {
  id: string;
  timestamp: string;
  input_hash: string;
  envelope: ComplianceEnvelope;
}