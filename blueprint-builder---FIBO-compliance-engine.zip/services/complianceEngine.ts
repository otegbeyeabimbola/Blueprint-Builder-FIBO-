import { ComplianceEnvelope } from '../types';

// Access environment variable for API URL with a local fallback
const API_URL = (import.meta as any).env?.VITE_API_URL || 'http://localhost:5000';

// --- Utilities ---

/**
 * Client-side hashing for Ledger Integrity Verification.
 * We keep this local to verify that data hasn't been tampered with
 * independent of the server.
 */
export const hashString = async (message: string): Promise<string> => {
  if (!crypto.subtle) {
    // Fallback for non-secure contexts if necessary, or throw error
    console.warn("Crypto API not available. Hashing disabled.");
    return "hash-unavailable";
  }
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return hashHex;
};

// --- Main Agentic Loop (API Integration) ---

/**
 * Sends the input JSON to the Python Backend for agentic compliance checking.
 */
export const runAgenticComplianceLoop = async (inputJson: string): Promise<ComplianceEnvelope> => {
  try {
    const response = await fetch(`${API_URL}/api/validate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      // The backend expects a JSON object with a "payload" key containing the stringified JSON
      body: JSON.stringify({ payload: inputJson }), 
    });

    if (!response.ok) {
       let errorMsg = response.statusText;
       try {
          const errData = await response.json();
          if (errData.detail) errorMsg = errData.detail;
       } catch (e) { /* ignore JSON parse error on failure */ }
       
       throw new Error(`Backend API Error (${response.status}): ${errorMsg}`);
    }

    const result: ComplianceEnvelope = await response.json();
    
    // Ensure timestamp exists for the frontend ledger (if backend didn't provide it)
    if (!result.timestamp) {
        result.timestamp = new Date().toISOString();
    }
    
    return result;

  } catch (err) {
    // Return a structured error envelope so the UI displays the error gracefully
    // rather than crashing white-screen.
     return {
          blueprint_version: "unknown",
          status: "FAILED_SCHEMA",
          exit_code: 2,
          trace_id: "error-trace",
          canonical_json: "",
          violations_history: [{
            category: "CRITICAL_PARSING_ERROR",
            type: "ConnectivityError",
            field: "API",
            description: String(err),
            fix_suggestion: "Ensure the backend is running and VITE_API_URL is set correctly."
          }],
          last_violations: [],
          iterations: 0,
          was_corrected_by_patcher: false,
          asset: null,
          timestamp: new Date().toISOString()
        };
  }
};

// --- Replay Validation Logic ---

export interface ReplayResult {
  integrity: boolean;
  valid: boolean;
  message: string;
}

/**
 * Verifies ledger entry by:
 * 1. Locally re-hashing the canonical JSON to verify data integrity.
 * 2. Sending the canonical JSON back to the server to verify it is still compliant.
 */
export const replayComplianceCheck = async (envelope: ComplianceEnvelope): Promise<ReplayResult> => {
  if (!envelope.canonical_json) {
     return { integrity: false, valid: false, message: "No canonical JSON found in envelope." };
  }

  // 1. Local Hash Integrity Check
  const calculatedTrace = await hashString(envelope.canonical_json);
  const hashMatch = calculatedTrace === envelope.trace_id;

  if (!hashMatch) {
    return { integrity: false, valid: false, message: "CRITICAL: Hash mismatch! Ledger entry corrupted." };
  }

  // 2. Remote Validation
  // We re-run the compliance loop on the canonical data.
  const reValidation = await runAgenticComplianceLoop(envelope.canonical_json);
  
  // Check if network failed during re-validation
  if (reValidation.violations_history.some(v => v.type === "ConnectivityError")) {
     return { integrity: true, valid: false, message: "Integrity Verified, but could not connect to server." };
  }

  const isValid = reValidation.status === 'SUCCESS';
  
  if (!isValid) {
      return { integrity: true, valid: false, message: "Integrity Verified, but asset fails current rules." };
  }

  return { integrity: true, valid: true, message: "Integrity Verified & Server Confirmed Compliance." };
};